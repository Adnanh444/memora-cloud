package com.adnan.memora.backup

import android.content.Context
import android.net.Uri
import com.adnan.memora.R
import com.adnan.memora.cloud.CloudUri
import com.adnan.memora.data.BackupState
import com.adnan.memora.gallery.BackupPhase
import com.adnan.memora.gallery.BackupSummary
import com.adnan.memora.gallery.ItemBackup
import com.adnan.memora.gallery.LocalMedia
import com.adnan.memora.gallery.MediaRepository
import com.adnan.memora.telegram.StorageStatus
import com.adnan.memora.telegram.TelegramClient
import com.adnan.memora.telegram.ThumbInfo
import com.adnan.memora.telegram.UploadResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException

fun LocalMedia.toEntry() = BackupEntry(
    uri = key, name = name, mime = mime, size = size, dateTaken = dateTaken, isVideo = isVideo,
)

/** A backed-up file as shown in the Cloud tab. The "uri" points at Telegram, not at the phone. */
fun BackupEntry.toCloudMedia() = LocalMedia(
    uri = CloudUri.thumb(chatId, messageId), name = name, mime = mime, size = size,
    dateTaken = dateTaken, dateModified = verifiedAt, width = 0, height = 0, durationMs = 0L,
    isVideo = isVideo, bucket = "Cloud",
)

/**
 * Queue -> hash while copying -> duplicate check -> upload to Telegram -> verify.
 * RULE: a file is only ever uploaded if its type (photos/videos) AND its folder are turned ON in Backup settings.
 * Original files on the phone are never deleted or modified by backup.
 */
object BackupEngine {
    private const val MAX_AUTO_ATTEMPTS = 5
    private const val MAX_FILE_BYTES = 2_000_000_000L
    private const val TRASH_DAYS = 30L

    private lateinit var appCtx: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val running = MutableStateFlow(false)
    @Volatile private var uploadJob: Job? = null
    private val live = MutableStateFlow<Pair<String, Float>?>(null)
    private val configFlow = MutableStateFlow<BackupConfig?>(null)

    private val _summary = MutableStateFlow(BackupSummary())
    val summary: StateFlow<BackupSummary> = _summary
    private val _items = MutableStateFlow<Map<String, ItemBackup>>(emptyMap())
    val items: StateFlow<Map<String, ItemBackup>> = _items
    private val _cloud = MutableStateFlow<List<BackupEntry>>(emptyList())
    val cloud: StateFlow<List<BackupEntry>> = _cloud
    private val _cloudTrash = MutableStateFlow<List<BackupEntry>>(emptyList())
    val cloudTrash: StateFlow<List<BackupEntry>> = _cloudTrash

    fun init(ctx: Context) {
        if (::appCtx.isInitialized) return
        appCtx = ctx.applicationContext
        configFlow.value = BackupSettings.load(appCtx)
        val dao = BackupDb.get(appCtx).dao()
        val tg = TelegramClient.get(appCtx)
        scope.launch {
            combine(dao.observeAll(), running, live, configFlow, tg.storageStatus) { entries, run, lv, cfg, st ->
                compute(entries, run, lv, cfg, st)
            }.collect { (sum, map) ->
                _summary.value = sum
                _items.value = map
            }
        }
        scope.launch {
            dao.observeAll().collect { entries ->
                _cloud.value = entries.filter { it.state == BackupEntry.ST_VERIFIED && it.messageId != 0L }
                    .distinctBy { it.chatId to it.messageId }.sortedByDescending { it.dateTaken }
                _cloudTrash.value = entries.filter { it.state == BackupEntry.ST_TRASHED }
                    .distinctBy { it.chatId to it.messageId }.sortedByDescending { it.trashedAt }
            }
        }
    }

    private fun compute(
        entries: List<BackupEntry>, run: Boolean, lv: Pair<String, Float>?, cfg: BackupConfig?, st: StorageStatus,
    ): Pair<BackupSummary, Map<String, ItemBackup>> {
        val map = HashMap<String, ItemBackup>(entries.size * 2)
        var done = 0
        var waiting = 0
        var total = 0
        var currentName: String? = null
        var currentProgress = 0f
        for (e in entries) {
            if (e.state == BackupEntry.ST_TRASHED || e.state == BackupEntry.ST_DELETED) continue
            if (e.uri.startsWith("cloud:")) continue // restored from the cloud, not a file of this phone
            total++
            val isLive = lv != null && lv.first == e.uri
            val item = when (e.state) {
                BackupEntry.ST_VERIFIED -> { done++; ItemBackup(BackupState.VERIFIED) }
                BackupEntry.ST_DUPLICATE -> { done++; ItemBackup(BackupState.VERIFIED, 0f, true) }
                BackupEntry.ST_UPLOADING -> {
                    if (isLive) { currentName = e.name; currentProgress = lv!!.second } else waiting++
                    ItemBackup(BackupState.UPLOADING, if (isLive) lv!!.second else 0f)
                }
                BackupEntry.ST_FAILED -> ItemBackup(BackupState.FAILED)
                else -> { waiting++; ItemBackup(BackupState.QUEUED) }
            }
            map[e.uri] = item
        }
        val active = (cfg?.enabled == true) || total > 0
        val ready = st is StorageStatus.Verified
        val phase = when {
            !active || !ready -> BackupPhase.NOT_SET_UP
            cfg?.paused == true -> BackupPhase.PAUSED
            run -> BackupPhase.RUNNING
            waiting > 0 -> BackupPhase.PAUSED
            else -> BackupPhase.IDLE
        }
        return BackupSummary(phase, done, total, currentName, currentProgress, cfg?.paused == true, waiting) to map
    }

    /** THE RULE. A file may upload only if its type is ON and its folder is ON. */
    fun isEligible(cfg: BackupConfig, isVideo: Boolean, bucket: String?): Boolean =
        bucket != null && bucket != "Memora" &&
            (if (isVideo) cfg.videos else cfg.photos) && bucket in cfg.folders

    /** Stops the upload running RIGHT NOW (it goes back to the queue) and keeps backup paused. */
    fun pause(ctx: Context) {
        val cfg = BackupSettings.load(ctx).copy(paused = true)
        BackupSettings.save(ctx, cfg)
        configFlow.value = cfg
        uploadJob?.cancel()
    }

    fun resume(ctx: Context) {
        val cfg = BackupSettings.load(ctx).copy(paused = false)
        BackupSettings.save(ctx, cfg)
        configFlow.value = cfg
        BackupScheduler.runNow(ctx, append = true)
    }

    fun updateConfig(ctx: Context, cfg: BackupConfig) {
        val old = configFlow.value ?: BackupSettings.load(ctx)
        BackupSettings.save(ctx, cfg)
        configFlow.value = cfg
        BackupScheduler.sync(ctx)
        val tightened = (old.photos && !cfg.photos) || (old.videos && !cfg.videos) ||
            (old.folders - cfg.folders).isNotEmpty()
        if (tightened) {
            // something was turned OFF: stop the running upload and drop everything that is no longer allowed
            uploadJob?.cancel()
            scope.launch {
                purgeIneligible(ctx, cfg)
                if (!cfg.paused) BackupScheduler.runNow(ctx, append = true)
            }
        } else if (cfg.enabled && !cfg.paused) {
            BackupScheduler.runNow(ctx)
        }
    }

    /** Removes queued/failed items whose type or folder is now OFF, so they can never upload. */
    suspend fun purgeIneligible(ctx: Context, cfg: BackupConfig = BackupSettings.load(ctx)) = withContext(Dispatchers.IO) {
        val dao = BackupDb.get(ctx).dao()
        val pending = dao.queuedOrFailed()
        if (pending.isEmpty()) return@withContext
        val media = MediaRepository(ctx).loadAll().associateBy { it.key }
        val bad = pending.filter { !isEligible(cfg, it.isVideo, media[it.uri]?.bucket) }.map { it.uri }
        bad.chunked(500).forEach { dao.deleteQueued(it) }
    }

    /** Finds new photos/videos in the allowed folders and adds them to the queue. */
    suspend fun scanAndEnqueue(ctx: Context): Int = withContext(Dispatchers.IO) {
        val cfg = BackupSettings.load(ctx)
        if (!cfg.enabled) return@withContext 0
        val dao = BackupDb.get(ctx).dao()
        val media = MediaRepository(ctx).loadAll()
        // photos already in the cloud (e.g. after a restore) are recognised by content and never uploaded again
        RecoveryEngine.matchLocal(ctx, media)
        val existing = dao.allKeys().toHashSet()
        val fresh = media.filter { m -> m.key !in existing && isEligible(cfg, m.isVideo, m.bucket) }.map { it.toEntry() }
        if (fresh.isNotEmpty()) dao.insertAll(fresh)
        fresh.size
    }

    /** Manual backup. Items whose type or folder is OFF are skipped. Returns (added, skipped). */
    suspend fun enqueueManual(ctx: Context, items: List<LocalMedia>): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val cfg = BackupSettings.load(ctx)
        val ok = items.filter { isEligible(cfg, it.isVideo, it.bucket) }
        val skipped = items.size - ok.size
        if (ok.isEmpty()) return@withContext Pair(0, skipped)
        val dao = BackupDb.get(ctx).dao()
        val existing = dao.allKeys().toHashSet()
        val fresh = ok.filter { it.key !in existing }.map { it.toEntry() }
        if (fresh.isNotEmpty()) dao.insertAll(fresh)
        ok.map { it.key }.chunked(500).forEach { dao.requeue(it); dao.requeueDeleted(it) }
        BackupScheduler.runNow(ctx)
        Pair(ok.size, skipped)
    }

    suspend fun retryFailed(ctx: Context) = withContext(Dispatchers.IO) {
        BackupDb.get(ctx).dao().retryAllFailed()
        BackupScheduler.runNow(ctx)
    }

    // ------------------------------------------------------------------ cloud library / cloud bin

    /** "Delete from cloud" for items chosen in the Cloud tab: moves them to the cloud bin (30 days). */
    suspend fun trashCloudMessages(msgs: List<Pair<Long, Long>>) = withContext(Dispatchers.IO) {
        val dao = BackupDb.get(appCtx).dao()
        val now = System.currentTimeMillis()
        msgs.distinct().forEach { dao.trashByMessage(it.first, it.second, now) }
    }

    /** "Delete from cloud" for photos chosen on the phone. */
    suspend fun trashCloudForLocal(ctx: Context, uris: List<String>) = withContext(Dispatchers.IO) {
        val dao = BackupDb.get(ctx).dao()
        val now = System.currentTimeMillis()
        uris.chunked(500).flatMap { dao.getMany(it) }
            .filter { it.messageId != 0L && (it.state == BackupEntry.ST_VERIFIED || it.state == BackupEntry.ST_DUPLICATE) }
            .map { it.chatId to it.messageId }.distinct()
            .forEach { dao.trashByMessage(it.first, it.second, now) }
    }

    suspend fun restoreCloud(msgs: List<Pair<Long, Long>>) = withContext(Dispatchers.IO) {
        val dao = BackupDb.get(appCtx).dao()
        msgs.distinct().forEach { dao.restoreByMessage(it.first, it.second) }
    }

    /** Permanently deletes the messages from Telegram. Returns true if Telegram confirmed. */
    suspend fun deleteCloudForever(ctx: Context, msgs: List<Pair<Long, Long>>): Boolean = withContext(Dispatchers.IO) {
        val dao = BackupDb.get(ctx).dao()
        val tg = TelegramClient.get(ctx)
        if (!tg.awaitUsable(30_000)) return@withContext false
        var all = true
        msgs.distinct().groupBy { it.first }.forEach { (chat, list) ->
            val ids = list.map { it.second }
            if (tg.deleteMessages(chat, ids)) ids.forEach { dao.tombstoneByMessage(chat, it) } else all = false
        }
        all
    }

    private suspend fun purgeExpiredCloudTrash(dao: BackupDao, tg: TelegramClient) {
        val expired = dao.expiredTrash(System.currentTimeMillis() - TRASH_DAYS * 24 * 3600 * 1000)
        expired.groupBy { it.chatId }.forEach { (chat, list) ->
            val ids = list.map { it.messageId }.distinct()
            if (tg.deleteMessages(chat, ids)) ids.forEach { dao.tombstoneByMessage(chat, it) }
        }
    }

    // ------------------------------------------------------------------ uploads

    /** Processes the queue one item at a time. Returns false if the cloud storage was not usable. */
    suspend fun runUploads(ctx: Context): Boolean {
        val dao = BackupDb.get(ctx).dao()
        val tg = TelegramClient.get(ctx)
        if (!tg.awaitUsable()) return false
        val chatId = tg.storage.value?.chatId ?: return false
        running.value = true
        try {
            purgeExpiredCloudTrash(dao, tg)
            dao.resetUploading()
            val todo = dao.pendingUris(MAX_AUTO_ATTEMPTS)
            val media = MediaRepository(ctx).loadAll().associateBy { it.key }
            coroutineScope {
                val job = launch {
                    for (uri in todo) {
                        val cfg = BackupSettings.load(ctx)
                        if (cfg.paused) break
                        val e = dao.get(uri) ?: continue
                        // the rule is checked again right before every single upload
                        if (!isEligible(cfg, e.isVideo, media[uri]?.bucket)) { dao.delete(uri); continue }
                        processOne(ctx, dao, tg, chatId, uri)
                    }
                }
                uploadJob = job
                job.join()
            }
        } finally {
            withContext(NonCancellable) {
                uploadJob = null
                running.value = false
                live.value = null
            }
        }
        return true
    }

    private fun safeName(n: String): String {
        val cleaned = n.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().take(120)
        return if (cleaned.isBlank()) "file" else cleaned
    }

    private suspend fun processOne(ctx: Context, dao: BackupDao, tg: TelegramClient, chatId: Long, uri: String) {
        var e = dao.get(uri) ?: return
        if (e.state == BackupEntry.ST_VERIFIED || e.state == BackupEntry.ST_DUPLICATE) return
        if (e.size > MAX_FILE_BYTES) {
            dao.update(e.copy(state = BackupEntry.ST_FAILED, attempts = 99, error = ctx.getString(R.string.bk_err_too_large)))
            return
        }
        val dir = File(ctx.cacheDir, "upload").apply { mkdirs() }
        if (dir.usableSpace < e.size + 50L * 1024 * 1024) {
            dao.update(e.copy(state = BackupEntry.ST_FAILED, attempts = e.attempts + 1, error = ctx.getString(R.string.bk_err_space)))
            return
        }
        e = e.copy(state = BackupEntry.ST_UPLOADING, error = null, attempts = e.attempts + 1)
        dao.update(e)
        live.value = e.uri to 0f
        val temp = File(dir, safeName(e.name))
        val thumbFile = File(dir, "preview_" + System.nanoTime() + ".jpg")
        try {
            val sha = try {
                Hashing.copyAndHash(ctx, Uri.parse(e.uri), temp)
            } catch (_: FileNotFoundException) {
                dao.delete(e.uri)
                return
            }
            val actualSize = temp.length()

            val twin = dao.findVerifiedByHash(sha, e.uri)
            if (twin != null) {
                val now = System.currentTimeMillis()
                dao.update(
                    e.copy(
                        sha256 = sha, state = BackupEntry.ST_DUPLICATE, duplicateOf = twin.uri,
                        chatId = twin.chatId, messageId = twin.messageId, verifiedAt = now, error = null,
                    )
                )
                return
            }

            val dims = Thumbs.make(ctx, Uri.parse(e.uri), e.isVideo, thumbFile)
            val thumb = if (dims != null) ThumbInfo(thumbFile.absolutePath, dims.first, dims.second) else null

            var lastReported = 0f
            val res = tg.uploadDocument(chatId, temp.absolutePath, "memora:v1 sha256=$sha taken=${e.dateTaken}", thumb) { p ->
                if (p - lastReported >= 0.05f || p >= 1f) { lastReported = p; live.value = e.uri to p }
            }
            val now = System.currentTimeMillis()
            when (res) {
                is UploadResult.Success -> {
                    if (tg.verifyMessage(chatId, res.messageId, actualSize)) {
                        dao.update(
                            e.copy(
                                sha256 = sha, state = BackupEntry.ST_VERIFIED, chatId = chatId, messageId = res.messageId,
                                uploadedAt = now, verifiedAt = now, error = null,
                            )
                        )
                    } else {
                        dao.update(e.copy(sha256 = sha, state = BackupEntry.ST_FAILED, error = ctx.getString(R.string.bk_err_verify)))
                    }
                }
                is UploadResult.Failure -> dao.update(e.copy(sha256 = sha, state = BackupEntry.ST_FAILED, error = res.message))
            }
        } catch (c: CancellationException) {
            withContext(NonCancellable) { dao.update(e.copy(state = BackupEntry.ST_QUEUED)) }
            throw c
        } catch (t: Exception) {
            dao.update(e.copy(state = BackupEntry.ST_FAILED, error = (t.message ?: "error").take(120)))
        } finally {
            temp.delete()
            thumbFile.delete()
        }
    }
}
