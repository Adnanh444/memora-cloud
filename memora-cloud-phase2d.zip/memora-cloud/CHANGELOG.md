# Changelog
## 0.3.0 — Google Photos-style experience
- Fast-scroll handle with month bubble; pull-down to refresh.
- Viewer: pinch + double-tap zoom, tap to hide controls, bottom action bar, swipe up for details
  (photo shrinks up, panel slides in), swipe down to close; EXIF camera info.
- Modern bottom sheets (delete shows From phone / From cloud / From both; settings choices).
- Library tab: device folders with cover photos, folder screens, Bin (phone trash, 30 days, restore / delete forever).
- Search (offline keyword search over name, folder, type, date).
- Backup strip + thumbnail status badges + upload-progress UI (shows real state; backup engine arrives in Phase 4).
## 0.2.2 — Share and Delete
## 0.2.1 — Futuristic UI + smaller APK
## 0.2.0 — Local Gallery
## 0.1.0 — Foundation
